import os
import glob


files = glob.glob('*.vhd')

for i in range(0, len(files)):
    file = open(os.getcwd()+'\\'+files[i],'r')
    content=file.read().splitlines()
    file.close()
    newname=files[i].split('.')[0]
    file = open(os.getcwd()+'\\'+newname+'.txt','w')
    address=0;
    for j in range(0, len(content)):
        if content[j].find('address')!=-1:
            newaddress=int(content[j].split(' ')[1],16)
            for k in range(0,newaddress-address):
                file.write("0000\n")
            address=newaddress
        else:
            file.write(content[j]+'\n')
            address=address+1
    file.close()
